﻿namespace P03_FootballBetting.Data.Configurations
{
    internal class Configuration
    {
        internal static string ConnectionString = @"Server=DESKTOP-M0LGMHO\SQLEXPRESS;Database=FootballBetting;Integrated Security=true;";
    }
}
