﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString => "Server=DESKTOP-M0LGMHO\\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
