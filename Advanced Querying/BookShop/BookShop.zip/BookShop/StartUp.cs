﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BookShop.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace BookShop
{
    using Data;
    using Initializer;

    public class StartUp
    {
        public static void Main()
        {
            var db = new BookShopContext();
            //DbInitializer.ResetDatabase(db);

            var command = Console.ReadLine();
            Console.WriteLine(GetBooksByAgeRestriction(db, command)); // Problem 1

            //  Console.WriteLine(GetGoldenBooks(db)); // Problem 2

            //  Console.WriteLine(GetBooksByPrice(db)); // Problem 3

            //  var year = int.Parse(Console.ReadLine());
            //  Console.WriteLine(GetBooksNotReleasedIn(db,year)); // Problem 4

            //  var input = Console.ReadLine();
            //  Console.WriteLine(GetBooksByCategory(db, input)); // Problem 5

            //  var input = Console.ReadLine();
            //  Console.WriteLine(GetBooksReleasedBefore(db, input)); // Problem 6

            //  var input = Console.ReadLine();
            //  Console.WriteLine(GetAuthorNamesEndingIn(db, input)); // Problem 7

            //  var input = Console.ReadLine();
            //  Console.WriteLine(GetBookTitlesContaining(db, input)); // Problem 8

            //  var input = Console.ReadLine();
            //  Console.WriteLine(GetBooksByAuthor(db, input)); // Problem 9

            //  var input = int.Parse(Console.ReadLine());
            //  Console.WriteLine(CountBooks(db, input)); // Problem 10

            //  Console.WriteLine(CountCopiesByAuthor(db)); // Problem 11

            //  Console.WriteLine(GetTotalProfitByCategory(db)); // Problem 12

            //  Console.WriteLine(GetMostRecentBooks(db)); // Problem 13

            //  IncreasePrices(db); // Problem 14

            //Console.WriteLine(RemoveBooks(db)); // Problem 15
        }

        // 1. Age Restriction
        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
            var result = new StringBuilder();
            var books = context
                  .Books
                  .Where(b => b.AgeRestriction.ToString().ToLower() == command.ToLower())
                  .Select(b => new
                  {
                      b.Title
                  })
                  .OrderBy(b => b.Title)
                  .ToList();
            foreach (var b in books)
            {
                result.AppendLine(b.Title);
            }

            return result.ToString().TrimEnd();
        }

        //2. Golden Books
        public static string GetGoldenBooks(BookShopContext context)
        {
            var result = new StringBuilder();

            var books = context
                .Books
                .Where(b => b.Copies < 5000 && b.EditionType.ToString() == "Gold")
                .Select(b => new
                {
                    b.Title,
                    b.BookId
                })
                .OrderBy(b => b.BookId)
                .ToList();

            foreach (var b in books)
            {
                result.AppendLine(b.Title);
            }

            return result.ToString().TrimEnd();
        }

        // 3. Books by Price

        public static string GetBooksByPrice(BookShopContext context)
        {
            var result = new StringBuilder();

            var books = context
                .Books
                .Where(b => b.Price > 40)
                .OrderByDescending(b => b.Price)
                .Select(b => new
                {
                    b.Title,
                    b.Price
                })
                .ToList();

            foreach (var book in books)
            {
                result.AppendLine(book.Title + " - $" + $"{book.Price:f2}");
            }

            return result.ToString().TrimEnd();
        }

        // 4. Not Released In
        public static string GetBooksNotReleasedIn(BookShopContext context, int year)
        {
            var result = new StringBuilder();

            var books = context
                .Books
                .Where(b => b.ReleaseDate.Value.Year != year)
                .Select(b => new
                {
                    b.Title,
                    b.BookId
                })
                .OrderBy(b => b.BookId)
                .ToList();

            foreach (var b in books)
            {
                result.AppendLine(b.Title);
            }

            return result.ToString().TrimEnd();
        }

        // 5. Book Titles by Category

        public static string GetBooksByCategory(BookShopContext context, string input)
        {
            var result = new StringBuilder();

            var categories = input
                .Split()
                .ToList();



            var books = context
                .Books
                .Select(b => new
                {
                    b.Title,
                    b.BookCategories,
                    CategorisName = b.BookCategories.Select(c => c.Category)

                })
                .OrderBy(b => b.Title)
                .ToList();

            foreach (var b in books)
            {
                foreach (var c in b.CategorisName)
                {
                    foreach (var cat in categories)
                    {
                        if (c.Name.ToLower() == cat.ToLower())
                        {
                            result.AppendLine(b.Title);
                        }
                    }
                }
            }

            return result.ToString().TrimEnd();
        }

        // 6. Released Before Date
        public static string GetBooksReleasedBefore(BookShopContext context, string date)
        {
            var result = new StringBuilder();
            var tokens = date
                .Split('-')
                .ToArray();
            var day = int.Parse(tokens[0]);
            var month = int.Parse(tokens[1]);
            var year = int.Parse(tokens[2]);

            var books = context
                .Books
                .OrderByDescending(b => b.ReleaseDate)
                .Where(b => b.ReleaseDate.Value < DateTime.ParseExact(date, "dd-MM-yyyy", null))
                .Select(b => new
                {
                    b.Title,
                    b.Price,
                    b.EditionType,
                    b.ReleaseDate
                })
                .ToList();

            foreach (var b in books)
            {
                result.AppendLine($"{b.Title} - {b.EditionType.ToString()} - ${b.Price:F2}");
            }

            return result.ToString().TrimEnd();
        }

        // 7. Author Search
        public static string GetAuthorNamesEndingIn(BookShopContext context, string input)
        {
            var result = new StringBuilder();

            var authors = context
                .Authors
                .Where(a => a.FirstName.EndsWith(input))
                .Select(a => new
                {
                    FullName = a.FirstName + ' ' + a.LastName
                })
                .OrderBy(a => a.FullName)
                .ToList();

            foreach (var a in authors)
            {
                result.AppendLine(a.FullName);
            }

            return result.ToString().TrimEnd();
        }

        // 8. Book Search
        public static string GetBookTitlesContaining(BookShopContext context, string input)
        {
            var result = new StringBuilder();

            var books = context
                .Books
                .Where(b => b.Title.ToLower().Contains(input.ToLower()))
                .Select(b => new
                {
                    b.Title
                })
                .OrderBy(b => b.Title)
                .ToList();

            foreach (var b in books)
            {
                result.AppendLine(b.Title);
            }

            return result.ToString().TrimEnd();
        }

        // 9. Book Search by Author
        public static string GetBooksByAuthor(BookShopContext context, string input)
        {
            var result = new StringBuilder();

            var books = context
                .Books
                .Where(b => b.Author.LastName.ToLower().StartsWith(input.ToLower()))
                .Select(b => new
                {
                    b.Title,
                    byAuthor = b.Author.FirstName + ' ' + b.Author.LastName,
                    b.BookId
                })
                .OrderBy(b => b.BookId);

            foreach (var b in books)
            {
                result.AppendLine($"{b.Title} ({b.byAuthor})");
            }

            return result.ToString().TrimEnd();
        }

        // 10. Count Books

        public static int CountBooks(BookShopContext context, int lengthCheck)
        {

            var books = context
                .Books
                .Where(b => b.Title.Length > lengthCheck)
                .ToList();

            return books.Count;
        }

        // 11. Total Book Copies

        public static string CountCopiesByAuthor(BookShopContext context)
        {
            var result = new StringBuilder();

            var authors = context
                .Authors
                .Select(a => new
                {
                    FullName = a.FirstName + ' ' + a.LastName,
                    Copies = a.Books.Sum(c => c.Copies)
                })
                .OrderByDescending(a => a.Copies)
                .ToList();

            foreach (var a in authors)
            {
                result.AppendLine($"{a.FullName} - {a.Copies}");
            }

            return result.ToString().TrimEnd();
        }

        // 12. Profit by Category

        public static string GetTotalProfitByCategory(BookShopContext context)
        {
            var result = new StringBuilder();

            var categories = context
                .Categories
                .Select(c => new
                {
                    c.Name,

                    SumOfCopies = c.CategoryBooks.Sum(cb => cb.Book.Copies * cb.Book.Price)
                })
                .OrderByDescending(ca => ca.SumOfCopies)
                .ThenBy(ca => ca.Name)
                .ToList();

            foreach (var ca in categories)
            {
                result.AppendLine($"{ca.Name} ${ca.SumOfCopies:f2}");
            }

            return result.ToString().TrimEnd();
        }

        // 13. Most Recent Books

        public static string GetMostRecentBooks(BookShopContext context)
        {
            var result = new StringBuilder();

            var categories = context
                .Categories
                .Select(c => new
                {
                    c.Name,
                    Books = c.CategoryBooks.OrderByDescending(ca => ca.Book.ReleaseDate.Value).Select(ca => new
                    {
                        BookName = ca.Book.Title,
                        Year = ca.Book.ReleaseDate.Value.Year
                    })
                        .Take(3)
                        .ToList()

                })
                .OrderBy(c => c.Name)
                .ToList();


            foreach (var c in categories)
            {
                result.AppendLine($"--{c.Name}");
                foreach (var book in c.Books)
                {
                    result.AppendLine($"{book.BookName} ({book.Year})");
                }
            }

            return result.ToString().TrimEnd();
        }


        // 14. Increase Prices - only 50/100 in SoftUniJudge


        public static void IncreasePrices(BookShopContext context)
        {

            context.Books
                .Where(b => b.ReleaseDate.Value.Year < 2010)
                .ToList()
                .ForEach(b => b.Price += 5);

            context.SaveChanges();

        }

        // 15. Remove Books - only 50/100 in SoftUniJudge
        public static int RemoveBooks(BookShopContext context)
        {

            var books = context
                .Books
                .Where(b => b.Copies < 4200)
                .ToList();

            foreach (var book in books)
            {
                context.Books.Remove(book);
            }

            context.SaveChanges();
            return books.Count;


        }



    }
}
