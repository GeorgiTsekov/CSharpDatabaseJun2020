﻿namespace P03_SalesDatabase.Data
{
    static class Configuration
    {
        internal static string ConnectionString = @"Server=DESKTOP-M0LGMHO\SQLEXPRESS;Database=SalesDatabase;Integrated Security=true;";
    }
}
