﻿namespace P01_HospitalDatabase.Data
{
    class Configuration
    {
        internal const string ConnectionString = @"Server=DESKTOP-M0LGMHO\SQLEXPRESS;Database=Hospital;Integrated Security=true;";
    }
}
