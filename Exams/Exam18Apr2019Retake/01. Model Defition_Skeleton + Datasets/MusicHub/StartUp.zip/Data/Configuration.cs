﻿namespace MusicHub.Data
{
   public static class Configuration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-M0LGMHO\SQLEXPRESS;Database=MusicHub;Trusted_Connection=True";
    }
}
