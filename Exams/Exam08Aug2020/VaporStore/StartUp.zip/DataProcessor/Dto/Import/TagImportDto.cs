﻿using System.ComponentModel.DataAnnotations;

namespace VaporStore.DataProcessor.Dto.Import
{
    public class TagImportDto
    {
        [Required]
        public string Name { get; set; }
    }
}
