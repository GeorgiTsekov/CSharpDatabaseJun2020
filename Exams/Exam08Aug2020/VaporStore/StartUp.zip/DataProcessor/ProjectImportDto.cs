﻿namespace VaporStore.DataProcessor
{
    internal class ProjectImportDto
    {
    }
}